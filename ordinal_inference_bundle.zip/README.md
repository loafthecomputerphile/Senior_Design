# Ordinal inference bundle

Inference/figure-regeneration only. No training, no augmentation experiment, no
checkpoint files. All predictions come from cached probabilities in
`run_state_3class/*.pt`.

## Setup

1. Extract this zip and run all cells from the extracted root (CWD matters).
2. The dataset is NOT included. Place the existing 1.66 GiB file at
   `data/final_processed_dataset.npz` (copy/hardlink/symlink from
   `project_notebooks/data/final_processed_dataset.npz` in the original repo).
3. Use the Python 3.13 venv/kernel from the project. Install `requirements.txt`.
   GPU is optional; allow several GB RAM for the NPZ.
4. Run cells top to bottom. `tables_3class/` and `figures_3class/` must be writable.

## Contents

- `ordinal_inference.ipynb` - setup, OOF eval, ensemble eval, CORAL tuning/figures.
- `modules/` - only the 9 local modules imported by that notebook.
- `figures_3class/*.png`, `tables_3class/*.csv` - all artifacts except `a2*`.
- `run_state_3class/*.pt` - cached OOF/ensemble/best predictions.

## Notes

- No network needed on the inference path. `ResNetModel.__init__` would need cached
  ImageNet weights, but no models are constructed in this notebook.
- `modules/dataset/make_dataset.py` imports `soundfile` at module load; it is in
  `requirements.txt`. It also calls `os.add_dll_directory()` only if an
  `ffmpeg_dlls/` folder exists; that folder is intentionally not bundled.
- Static-only artifacts (shipped but not regenerated because their per-fold test
  probabilities lived in excluded checkpoints):
  `best_cvfold_test_giant.png`, `best_f1_fold_test_giant.png`,
  `best_cvfold_test_eval.csv`, `best_f1_fold_test_eval.csv`.
- All `a2*` augmentation artifacts are intentionally excluded.
